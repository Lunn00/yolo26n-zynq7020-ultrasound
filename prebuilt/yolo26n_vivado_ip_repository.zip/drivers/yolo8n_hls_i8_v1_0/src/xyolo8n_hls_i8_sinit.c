// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xyolo8n_hls_i8.h"

extern XYolo8n_hls_i8_Config XYolo8n_hls_i8_ConfigTable[];

XYolo8n_hls_i8_Config *XYolo8n_hls_i8_LookupConfig(u16 DeviceId) {
	XYolo8n_hls_i8_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XYOLO8N_HLS_I8_NUM_INSTANCES; Index++) {
		if (XYolo8n_hls_i8_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XYolo8n_hls_i8_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XYolo8n_hls_i8_Initialize(XYolo8n_hls_i8 *InstancePtr, u16 DeviceId) {
	XYolo8n_hls_i8_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XYolo8n_hls_i8_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XYolo8n_hls_i8_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

