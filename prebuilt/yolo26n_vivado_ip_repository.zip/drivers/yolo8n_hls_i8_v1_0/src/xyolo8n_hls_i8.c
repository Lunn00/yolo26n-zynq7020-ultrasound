// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xyolo8n_hls_i8.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XYolo8n_hls_i8_CfgInitialize(XYolo8n_hls_i8 *InstancePtr, XYolo8n_hls_i8_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XYolo8n_hls_i8_Start(XYolo8n_hls_i8 *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_AP_CTRL) & 0x80;
    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XYolo8n_hls_i8_IsDone(XYolo8n_hls_i8 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XYolo8n_hls_i8_IsIdle(XYolo8n_hls_i8 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XYolo8n_hls_i8_IsReady(XYolo8n_hls_i8 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XYolo8n_hls_i8_EnableAutoRestart(XYolo8n_hls_i8 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XYolo8n_hls_i8_DisableAutoRestart(XYolo8n_hls_i8 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_AP_CTRL, 0);
}

void XYolo8n_hls_i8_Set_input_r(XYolo8n_hls_i8 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_INPUT_R_DATA, (u32)(Data));
    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_INPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XYolo8n_hls_i8_Get_input_r(XYolo8n_hls_i8 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_INPUT_R_DATA);
    Data += (u64)XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_INPUT_R_DATA + 4) << 32;
    return Data;
}

void XYolo8n_hls_i8_Set_weights(XYolo8n_hls_i8 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_WEIGHTS_DATA, (u32)(Data));
    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_WEIGHTS_DATA + 4, (u32)(Data >> 32));
}

u64 XYolo8n_hls_i8_Get_weights(XYolo8n_hls_i8 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_WEIGHTS_DATA);
    Data += (u64)XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_WEIGHTS_DATA + 4) << 32;
    return Data;
}

void XYolo8n_hls_i8_Set_fixed_params(XYolo8n_hls_i8 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_FIXED_PARAMS_DATA, (u32)(Data));
    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_FIXED_PARAMS_DATA + 4, (u32)(Data >> 32));
}

u64 XYolo8n_hls_i8_Get_fixed_params(XYolo8n_hls_i8 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_FIXED_PARAMS_DATA);
    Data += (u64)XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_FIXED_PARAMS_DATA + 4) << 32;
    return Data;
}

void XYolo8n_hls_i8_Set_work(XYolo8n_hls_i8 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_WORK_DATA, (u32)(Data));
    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_WORK_DATA + 4, (u32)(Data >> 32));
}

u64 XYolo8n_hls_i8_Get_work(XYolo8n_hls_i8 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_WORK_DATA);
    Data += (u64)XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_WORK_DATA + 4) << 32;
    return Data;
}

void XYolo8n_hls_i8_Set_pred_r(XYolo8n_hls_i8 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_PRED_R_DATA, (u32)(Data));
    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_PRED_R_DATA + 4, (u32)(Data >> 32));
}

u64 XYolo8n_hls_i8_Get_pred_r(XYolo8n_hls_i8 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_PRED_R_DATA);
    Data += (u64)XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_PRED_R_DATA + 4) << 32;
    return Data;
}

void XYolo8n_hls_i8_InterruptGlobalEnable(XYolo8n_hls_i8 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_GIE, 1);
}

void XYolo8n_hls_i8_InterruptGlobalDisable(XYolo8n_hls_i8 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_GIE, 0);
}

void XYolo8n_hls_i8_InterruptEnable(XYolo8n_hls_i8 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_IER);
    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_IER, Register | Mask);
}

void XYolo8n_hls_i8_InterruptDisable(XYolo8n_hls_i8 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_IER);
    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_IER, Register & (~Mask));
}

void XYolo8n_hls_i8_InterruptClear(XYolo8n_hls_i8 *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XYolo8n_hls_i8_WriteReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_ISR, Mask);
}

u32 XYolo8n_hls_i8_InterruptGetEnabled(XYolo8n_hls_i8 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_IER);
}

u32 XYolo8n_hls_i8_InterruptGetStatus(XYolo8n_hls_i8 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XYolo8n_hls_i8_ReadReg(InstancePtr->Control_BaseAddress, XYOLO8N_HLS_I8_CONTROL_ADDR_ISR);
}

