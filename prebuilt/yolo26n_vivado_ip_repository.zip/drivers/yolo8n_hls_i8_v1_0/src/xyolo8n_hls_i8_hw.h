// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        bit 5 - enable ap_local_deadlock interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (COR/TOW)
//        bit 1 - ap_ready (COR/TOW)
//        bit 5 - ap_local_deadlock (COR/TOW)
//        others - reserved
// 0x10 : Data signal of input_r
//        bit 31~0 - input_r[31:0] (Read/Write)
// 0x14 : Data signal of input_r
//        bit 31~0 - input_r[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of weights
//        bit 31~0 - weights[31:0] (Read/Write)
// 0x20 : Data signal of weights
//        bit 31~0 - weights[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of fixed_params
//        bit 31~0 - fixed_params[31:0] (Read/Write)
// 0x2c : Data signal of fixed_params
//        bit 31~0 - fixed_params[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of work
//        bit 31~0 - work[31:0] (Read/Write)
// 0x38 : Data signal of work
//        bit 31~0 - work[63:32] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of pred_r
//        bit 31~0 - pred_r[31:0] (Read/Write)
// 0x44 : Data signal of pred_r
//        bit 31~0 - pred_r[63:32] (Read/Write)
// 0x48 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XYOLO8N_HLS_I8_CONTROL_ADDR_AP_CTRL           0x00
#define XYOLO8N_HLS_I8_CONTROL_ADDR_GIE               0x04
#define XYOLO8N_HLS_I8_CONTROL_ADDR_IER               0x08
#define XYOLO8N_HLS_I8_CONTROL_ADDR_ISR               0x0c
#define XYOLO8N_HLS_I8_CONTROL_ADDR_INPUT_R_DATA      0x10
#define XYOLO8N_HLS_I8_CONTROL_BITS_INPUT_R_DATA      64
#define XYOLO8N_HLS_I8_CONTROL_ADDR_WEIGHTS_DATA      0x1c
#define XYOLO8N_HLS_I8_CONTROL_BITS_WEIGHTS_DATA      64
#define XYOLO8N_HLS_I8_CONTROL_ADDR_FIXED_PARAMS_DATA 0x28
#define XYOLO8N_HLS_I8_CONTROL_BITS_FIXED_PARAMS_DATA 64
#define XYOLO8N_HLS_I8_CONTROL_ADDR_WORK_DATA         0x34
#define XYOLO8N_HLS_I8_CONTROL_BITS_WORK_DATA         64
#define XYOLO8N_HLS_I8_CONTROL_ADDR_PRED_R_DATA       0x40
#define XYOLO8N_HLS_I8_CONTROL_BITS_PRED_R_DATA       64

