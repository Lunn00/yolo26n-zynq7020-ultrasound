// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XYOLO8N_HLS_I8_H
#define XYOLO8N_HLS_I8_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xyolo8n_hls_i8_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XYolo8n_hls_i8_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XYolo8n_hls_i8;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XYolo8n_hls_i8_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XYolo8n_hls_i8_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XYolo8n_hls_i8_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XYolo8n_hls_i8_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XYolo8n_hls_i8_Initialize(XYolo8n_hls_i8 *InstancePtr, u16 DeviceId);
XYolo8n_hls_i8_Config* XYolo8n_hls_i8_LookupConfig(u16 DeviceId);
int XYolo8n_hls_i8_CfgInitialize(XYolo8n_hls_i8 *InstancePtr, XYolo8n_hls_i8_Config *ConfigPtr);
#else
int XYolo8n_hls_i8_Initialize(XYolo8n_hls_i8 *InstancePtr, const char* InstanceName);
int XYolo8n_hls_i8_Release(XYolo8n_hls_i8 *InstancePtr);
#endif

void XYolo8n_hls_i8_Start(XYolo8n_hls_i8 *InstancePtr);
u32 XYolo8n_hls_i8_IsDone(XYolo8n_hls_i8 *InstancePtr);
u32 XYolo8n_hls_i8_IsIdle(XYolo8n_hls_i8 *InstancePtr);
u32 XYolo8n_hls_i8_IsReady(XYolo8n_hls_i8 *InstancePtr);
void XYolo8n_hls_i8_EnableAutoRestart(XYolo8n_hls_i8 *InstancePtr);
void XYolo8n_hls_i8_DisableAutoRestart(XYolo8n_hls_i8 *InstancePtr);

void XYolo8n_hls_i8_Set_input_r(XYolo8n_hls_i8 *InstancePtr, u64 Data);
u64 XYolo8n_hls_i8_Get_input_r(XYolo8n_hls_i8 *InstancePtr);
void XYolo8n_hls_i8_Set_weights(XYolo8n_hls_i8 *InstancePtr, u64 Data);
u64 XYolo8n_hls_i8_Get_weights(XYolo8n_hls_i8 *InstancePtr);
void XYolo8n_hls_i8_Set_fixed_params(XYolo8n_hls_i8 *InstancePtr, u64 Data);
u64 XYolo8n_hls_i8_Get_fixed_params(XYolo8n_hls_i8 *InstancePtr);
void XYolo8n_hls_i8_Set_work(XYolo8n_hls_i8 *InstancePtr, u64 Data);
u64 XYolo8n_hls_i8_Get_work(XYolo8n_hls_i8 *InstancePtr);
void XYolo8n_hls_i8_Set_pred_r(XYolo8n_hls_i8 *InstancePtr, u64 Data);
u64 XYolo8n_hls_i8_Get_pred_r(XYolo8n_hls_i8 *InstancePtr);

void XYolo8n_hls_i8_InterruptGlobalEnable(XYolo8n_hls_i8 *InstancePtr);
void XYolo8n_hls_i8_InterruptGlobalDisable(XYolo8n_hls_i8 *InstancePtr);
void XYolo8n_hls_i8_InterruptEnable(XYolo8n_hls_i8 *InstancePtr, u32 Mask);
void XYolo8n_hls_i8_InterruptDisable(XYolo8n_hls_i8 *InstancePtr, u32 Mask);
void XYolo8n_hls_i8_InterruptClear(XYolo8n_hls_i8 *InstancePtr, u32 Mask);
u32 XYolo8n_hls_i8_InterruptGetEnabled(XYolo8n_hls_i8 *InstancePtr);
u32 XYolo8n_hls_i8_InterruptGetStatus(XYolo8n_hls_i8 *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
