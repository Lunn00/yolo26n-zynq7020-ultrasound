-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity yolo8n_hls_i8_yolo_layers_i8_silu_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 1; 
             AddressWidth     : integer := 7; 
             AddressRange    : integer := 111
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of yolo8n_hls_i8_yolo_layers_i8_silu_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 => "0", 1 to 3=> "1", 4 => "0", 5 to 9=> "1", 10 => "0", 11 to 15=> "1", 16 => "0", 
    17 to 26=> "1", 27 => "0", 28 to 35=> "1", 36 to 39=> "0", 40 to 41=> "1", 42 to 43=> "0", 44 => "1", 
    45 => "0", 46 to 47=> "1", 48 => "0", 49 to 57=> "1", 58 => "0", 59 to 68=> "1", 69 => "0", 
    70 to 79=> "1", 80 => "0", 81 to 82=> "1", 83 => "0", 84 => "1", 85 => "0", 86 to 88=> "1", 
    89 => "0", 90 to 91=> "1", 92 => "0", 93 to 94=> "1", 95 => "0", 96 to 99=> "1", 100 => "0", 
    101 to 104=> "1", 105 => "0", 106 to 109=> "1", 110 => "0" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
    end if;
end process;

end rtl;

