-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity yolo8n_hls_i8_yolo_layers_i8_k_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 3; 
             AddressWidth     : integer := 7; 
             AddressRange    : integer := 111
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of yolo8n_hls_i8_yolo_layers_i8_k_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 => "000", 1 to 2=> "011", 3 => "001", 4 => "000", 5 to 6=> "011", 7 => "001", 
    8 => "011", 9 => "001", 10 => "000", 11 to 12=> "011", 13 => "001", 14 => "011", 
    15 => "001", 16 => "000", 17 => "001", 18 to 21=> "011", 22 to 24=> "001", 25 => "011", 
    26 => "001", 27 => "000", 28 => "001", 29 to 32=> "011", 33 to 36=> "001", 37 to 39=> "101", 
    40 to 41=> "001", 42 => "000", 43 to 47=> "001", 48 => "000", 49 => "001", 50 to 53=> "011", 
    54 to 57=> "001", 58 => "000", 59 => "001", 60 to 63=> "011", 64 to 66=> "001", 67 => "011", 
    68 => "001", 69 => "000", 70 => "001", 71 to 74=> "011", 75 to 77=> "001", 78 => "011", 
    79 => "001", 80 => "000", 81 to 82=> "011", 83 to 86=> "001", 87 to 88=> "011", 89 => "001", 
    90 to 91=> "011", 92 => "001", 93 to 94=> "011", 95 => "001", 96 => "011", 97 => "001", 
    98 => "011", 99 to 100=> "001", 101 => "011", 102 => "001", 103 => "011", 104 to 105=> "001", 
    106 => "011", 107 => "001", 108 => "011", 109 to 110=> "001" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
    end if;
end process;

end rtl;

