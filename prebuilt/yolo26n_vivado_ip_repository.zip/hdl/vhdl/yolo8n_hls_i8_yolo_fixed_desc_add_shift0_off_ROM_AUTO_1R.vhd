-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity yolo8n_hls_i8_yolo_fixed_desc_add_shift0_off_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 18; 
             AddressWidth     : integer := 7; 
             AddressRange    : integer := 111
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of yolo8n_hls_i8_yolo_fixed_desc_add_shift0_off_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 to 5=> "000000000000000000", 6 => "000000101000010000", 
    7 to 11=> "000000000000000000", 12 => "000010001000110000", 
    13 to 18=> "000000000000000000", 19 => "000101000110110000", 
    20 => "000000000000000000", 21 => "000101101000110000", 
    22 to 29=> "000000000000000000", 30 => "001011010011110000", 
    31 => "000000000000000000", 32 => "001100010111110000", 
    33 to 39=> "000000000000000000", 40 => "010001111101110000", 
    41 to 42=> "000000000000000000", 43 => "010100111101110000", 
    44 => "000000000000000000", 45 => "010111100101110000", 
    46 to 50=> "000000000000000000", 51 => "011010111110110000", 
    52 => "000000000000000000", 53 => "011011100000110000", 
    54 to 60=> "000000000000000000", 61 => "011101110000010000", 
    62 => "000000000000000000", 63 => "011110000001010000", 
    64 to 71=> "000000000000000000", 72 => "100000100010110000", 
    73 => "000000000000000000", 74 => "100001000100110000", 
    75 to 81=> "000000000000000000", 82 => "100110001101110000", 
    83 => "100111010101110000", 84 => "000000000000000000", 
    85 => "101001111101110000", 86 to 110=> "000000000000000000" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
    end if;
end process;

end rtl;

