-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity yolo8n_hls_i8_yolo_layers_i8_pad_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 2; 
             AddressWidth     : integer := 7; 
             AddressRange    : integer := 111
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of yolo8n_hls_i8_yolo_layers_i8_pad_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 => "00", 1 to 2=> "01", 3 to 4=> "00", 5 to 6=> "01", 7 => "00", 8 => "01", 
    9 to 10=> "00", 11 to 12=> "01", 13 => "00", 14 => "01", 15 to 17=> "00", 18 to 21=> "01", 
    22 to 24=> "00", 25 => "01", 26 to 28=> "00", 29 to 32=> "01", 33 to 36=> "00", 37 to 39=> "10", 
    40 to 49=> "00", 50 to 53=> "01", 54 to 59=> "00", 60 to 63=> "01", 64 to 66=> "00", 67 => "01", 
    68 to 70=> "00", 71 to 74=> "01", 75 to 77=> "00", 78 => "01", 79 to 80=> "00", 81 to 82=> "01", 
    83 to 86=> "00", 87 to 88=> "01", 89 => "00", 90 to 91=> "01", 92 => "00", 93 to 94=> "01", 
    95 => "00", 96 => "01", 97 => "00", 98 => "01", 99 to 100=> "00", 101 => "01", 
    102 => "00", 103 => "01", 104 to 105=> "00", 106 => "01", 107 => "00", 108 => "01", 
    109 to 110=> "00" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
    end if;
end process;

end rtl;

