-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity yolo8n_hls_i8_yolo_layers_i8_out_stride_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 13; 
             AddressWidth     : integer := 7; 
             AddressRange    : integer := 111
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of yolo8n_hls_i8_yolo_layers_i8_out_stride_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 => "0000000000001", 1 => "1000100000000", 2 to 3=> "0110001000000", 
    4 => "0000000000001", 5 to 7=> "0110001000000", 8 to 9=> "0001100010000", 
    10 => "0000000000001", 11 to 13=> "0001100010000", 14 to 15=> "0000011000100", 
    16 => "0000000000001", 17 to 24=> "0000011000100", 25 to 26=> "0000000110001", 
    27 => "0000000000001", 28 to 36=> "0000000110001", 37 to 39=> "0000000000001", 
    40 to 41=> "0000000110001", 42 => "0000000000001", 43 to 46=> "0000000110001", 
    47 => "0000011000100", 48 => "0000000000001", 49 to 56=> "0000011000100", 
    57 => "0001100010000", 58 => "0000000000001", 59 to 66=> "0001100010000", 
    67 to 68=> "0000011000100", 69 => "0000000000001", 70 to 77=> "0000011000100", 
    78 to 79=> "0000000110001", 80 => "0000000000001", 81 to 86=> "0000000110001", 
    87 to 88=> "0001100010000", 89 => "0010000000101", 90 to 91=> "0000011000100", 
    92 => "0010000000101", 93 to 94=> "0000000110001", 95 => "0010000000101", 
    96 to 99=> "0001100010000", 100 => "0000000000001", 101 to 104=> "0000011000100", 
    105 => "0000000000001", 106 to 109=> "0000000110001", 110 => "0000000000001" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
    end if;
end process;

end rtl;

