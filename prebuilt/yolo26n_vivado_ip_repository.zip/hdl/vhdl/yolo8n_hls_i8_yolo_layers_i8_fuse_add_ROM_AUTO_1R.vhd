-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity yolo8n_hls_i8_yolo_layers_i8_fuse_add_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 1; 
             AddressWidth     : integer := 7; 
             AddressRange    : integer := 111
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of yolo8n_hls_i8_yolo_layers_i8_fuse_add_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 to 5=> "0", 6 => "1", 7 to 11=> "0", 12 => "1", 13 to 18=> "0", 19 => "1", 20 => "0", 
    21 => "1", 22 to 29=> "0", 30 => "1", 31 => "0", 32 => "1", 33 to 39=> "0", 40 => "1", 
    41 to 42=> "0", 43 => "1", 44 => "0", 45 => "1", 46 to 50=> "0", 51 => "1", 52 => "0", 
    53 => "1", 54 to 60=> "0", 61 => "1", 62 => "0", 63 => "1", 64 to 71=> "0", 72 => "1", 
    73 => "0", 74 => "1", 75 to 81=> "0", 82 to 83=> "1", 84 => "0", 85 => "1", 86 to 110=> "0" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
    end if;
end process;

end rtl;

