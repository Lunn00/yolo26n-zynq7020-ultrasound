-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity yolo8n_hls_i8_yolo_layers_i8_add_off_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 20; 
             AddressWidth     : integer := 7; 
             AddressRange    : integer := 111
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of yolo8n_hls_i8_yolo_layers_i8_add_off_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 to 5=> "00000000000000000000", 6 => "00110001000000000000", 
    7 to 11=> "00000000000000000000", 12 => "01110100011000000000", 
    13 to 18=> "00000000000000000000", 19 => "01010101110000000000", 
    20 => "00000000000000000000", 21 => "00100100110000000000", 
    22 to 29=> "00000000000000000000", 30 => "00100100110000000000", 
    31 => "00000000000000000000", 32 => "01111010100000000000", 
    33 to 39=> "00000000000000000000", 40 => "11001110101110000000", 
    41 to 42=> "00000000000000000000", 43 => "11010000010000000000", 
    44 => "00000000000000000000", 45 => "11000100000000000000", 
    46 to 50=> "00000000000000000000", 51 => "11010001110010000000", 
    52 => "00000000000000000000", 53 => "11000100000000000000", 
    54 to 60=> "00000000000000000000", 61 => "11010111111010000000", 
    62 => "00000000000000000000", 63 => "10101011100000000000", 
    64 to 71=> "00000000000000000000", 72 => "11010011010100000000", 
    73 => "00000000000000000000", 74 => "11001110101110000000", 
    75 to 81=> "00000000000000000000", 82 => "10101101000010000000", 
    83 => "11100001000110000000", 84 => "00000000000000000000", 
    85 => "11010001110010000000", 86 to 110=> "00000000000000000000" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
    end if;
end process;

end rtl;

