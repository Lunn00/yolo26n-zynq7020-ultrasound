-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity yolo8n_hls_i8_yolo_layers_i8_oc_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 9; 
             AddressWidth     : integer := 7; 
             AddressRange    : integer := 111
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of yolo8n_hls_i8_yolo_layers_i8_oc_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 => "000000011", 1 => "000010000", 2 to 4=> "000100000", 5 => "000001000", 
    6 => "000010000", 7 to 10=> "001000000", 11 => "000010000", 12 => "000100000", 
    13 to 16=> "010000000", 17 to 22=> "000100000", 23 => "001000000", 24 => "010000000", 
    25 to 27=> "100000000", 28 to 33=> "001000000", 34 => "010000000", 35 => "100000000", 
    36 to 39=> "010000000", 40 to 42=> "100000000", 43 => "010000000", 44 => "100000000", 
    45 => "010000000", 46 => "100000000", 47 to 48=> "010000000", 49 to 54=> "000100000", 
    55 => "001000000", 56 => "010000000", 57 to 58=> "001000000", 59 to 64=> "000010000", 
    65 => "000100000", 66 to 67=> "001000000", 68 to 69=> "010000000", 70 to 75=> "000100000", 
    76 => "001000000", 77 to 78=> "010000000", 79 to 80=> "100000000", 81 => "001000000", 
    82 to 83=> "010000000", 84 => "100000000", 85 => "010000000", 86 => "100000000", 
    87 to 88=> "000010000", 89 => "000000100", 90 to 91=> "000010000", 92 => "000000100", 
    93 to 94=> "000010000", 95 => "000000100", 96 to 99=> "001000000", 100 => "000000001", 
    101 => "010000000", 102 to 104=> "001000000", 105 => "000000001", 106 => "100000000", 
    107 to 109=> "001000000", 110 => "000000001" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
    end if;
end process;

end rtl;

