-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
-- Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity yolo8n_hls_i8_yolo_layers_i8_ic_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 10; 
             AddressWidth     : integer := 7; 
             AddressRange    : integer := 111
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of yolo8n_hls_i8_yolo_layers_i8_ic_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 => "0000000000", 1 => "0000000011", 2 => "0000010000", 3 => "0000100000", 
    4 => "0000000000", 5 => "0000010000", 6 => "0000001000", 7 => "0000110000", 
    8 to 9=> "0001000000", 10 => "0000000000", 11 => "0000100000", 12 => "0000010000", 
    13 => "0001100000", 14 to 15=> "0010000000", 16 => "0000000000", 17 => "0001000000", 
    18 to 21=> "0000100000", 22 to 23=> "0001000000", 24 => "0011000000", 25 => "0010000000", 
    26 => "0100000000", 27 => "0000000000", 28 => "0010000000", 29 to 32=> "0001000000", 
    33 to 34=> "0010000000", 35 => "0110000000", 36 => "0100000000", 37 to 39=> "0000000000", 
    40 => "1000000000", 41 => "0100000000", 42 => "0000000000", 43 to 44=> "0010000000", 
    45 to 46=> "0100000000", 47 => "0110000000", 48 => "0000000000", 49 => "0001000000", 
    50 to 53=> "0000100000", 54 to 55=> "0001000000", 56 => "0011000000", 57 => "0100000000", 
    58 => "0000000000", 59 => "0000100000", 60 to 63=> "0000010000", 64 to 65=> "0000100000", 
    66 => "0001100000", 67 => "0001000000", 68 => "0011000000", 69 => "0000000000", 
    70 => "0001000000", 71 to 74=> "0000100000", 75 to 76=> "0001000000", 77 => "0011000000", 
    78 => "0010000000", 79 => "0110000000", 80 => "0000000000", 81 => "0010000000", 
    82 => "0001000000", 83 to 84=> "0010000000", 85 => "0100000000", 86 => "0110000000", 
    87 => "0001000000", 88 to 89=> "0000010000", 90 => "0010000000", 91 to 92=> "0000010000", 
    93 => "0100000000", 94 to 95=> "0000010000", 96 to 100=> "0001000000", 101 to 102=> "0010000000", 
    103 to 105=> "0001000000", 106 to 107=> "0100000000", 108 to 110=> "0001000000" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
    end if;
end process;

end rtl;

